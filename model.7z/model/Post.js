const mongoose = require("mongoose");

const Tsf_schema = mongoose.Schema({
    user_id:{
     
    },
    name: {
        type: String,
        required: true
    },
    email_id: {
        type: String,
        required: true
    }
})
